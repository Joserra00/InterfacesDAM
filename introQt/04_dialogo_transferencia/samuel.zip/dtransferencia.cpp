#include "dtransferencia.h"


Dtransferencia::Dtransferencia(QWidget *parent):QDialog(parent){
	resize(200,300); 
	principal = new QHBoxLayout();
	cuentaH = new QHBoxLayout();
	cantidadH = new QHBoxLayout();
	vertical1 = new QVBoxLayout();
	vertical2 = new QVBoxLayout();
	interes = new QLabel("Comisión operación: ");
	cuenta = new QLabel("Cuenta destino: ");
	cantidad = new QLabel("Cantidad: ");
	destino = new QLineEdit();
	ecantidad = new QLineEdit();


	aceptar = new QPushButton("Aceptar");
	cancelar = new QPushButton("Cancelar");
	aceptar->setEnabled(false);
	cuentaH->addWidget(cuenta);
	cuentaH->addWidget(destino);
	cantidadH->addWidget(cantidad);
	cantidadH->addWidget(ecantidad);
	vertical2->addWidget(aceptar);
	vertical2->addWidget(cancelar);
	
	vertical1->addLayout(cuentaH);
	vertical1->addLayout(cantidadH);
	principal->addLayout(vertical1);
	principal->addLayout(vertical2);
	setLayout(principal);
}
void Dtransferencia::slotActualizarBoton(const QSTring &cad){
	

}
void Dtransferencia::slotActualizarComision(const QSTring &cad){
	
	
	}
	

